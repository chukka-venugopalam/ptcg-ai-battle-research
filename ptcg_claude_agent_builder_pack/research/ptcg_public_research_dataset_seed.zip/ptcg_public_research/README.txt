PTCG AI Battle Public Research Dataset — seed package

Attach this dataset to the Kaggle notebook 00_bootstrap_public_research.ipynb.

It contains the source manifest plus a reproducible fetcher. The repository
snapshots are intentionally not embedded in this seed package because third-
party licensing and model redistribution terms differ. After license review,
run the notebook with Internet enabled or upload approved snapshots under
repos/.

The current competition ZIP is a separate user-supplied/competition-authorized
input and is inventoried in current_competition_inventory.csv.
