#!/usr/bin/env python3
"""Reproduces legacy-harness defect D2 (cwd) against the REAL cabt engine (kaggle-environments 1.33.0).
Legacy flow (reserch2 bo3_ab_harness.py lines 63-68):  paths=[cand_main, opp_main]; os.chdir(dirname(cand_main)); env.run(paths)
Agents here read 'deck.csv' relative to the cwd (the common way to write main.py without __file__)."""
import os, sys, tempfile, shutil, traceback
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "tests"))
import agent_fixtures as F
from kaggle_environments import make

td = tempfile.mkdtemp()
A = F.make_agents(td)
cand, opp = A["helper_x"], A["rand_cwd"]            # helper_x ignores cwd; use two cwd-readers instead:
shutil.copytree(A["rand_cwd"], os.path.join(td, "cand_cwd"))
shutil.copytree(A["rand_cwd"], os.path.join(td, "opp_cwd"))
# give the OPPONENT a different (legal) deck than the candidate
open(os.path.join(td, "opp_cwd", "deck.csv"), "w").write("\n".join(map(str, A["_deck2"])) + "\n")
cand, opp = os.path.join(td, "cand_cwd"), os.path.join(td, "opp_cwd")
print("candidate deck == sdk deck:", open(os.path.join(cand, "deck.csv")).read().split() == [str(x) for x in A["_deck"]])
print("opponent  deck == variant :", open(os.path.join(opp, "deck.csv")).read().split() == [str(x) for x in A["_deck2"]])

print("\n[legacy flow, absolute paths] chdir(candidate dir) then env.run([cand/main.py, opp/main.py])")
os.chdir(cand)
env = make("cabt", configuration={"bo": 3})
env.run([os.path.join(cand, "main.py"), os.path.join(opp, "main.py")])
d0, d1 = env.steps[1][0].action, env.steps[2][1].action if len(env.steps) > 2 else None
decks = [s.action for st in env.steps[1:3] for s in st if isinstance(s.action, list) and len(s.action) == 60]
print("deck submitted by seat0 (candidate):", "SDK deck" if decks[0] == A["_deck"] else "variant")
print("deck submitted by seat1 (OPPONENT) :", "SDK deck" if decks[1] == A["_deck"] else "variant",
      "  <-- opponent was supposed to play the variant deck" if decks[1] == A["_deck"] else "")

print("\n[legacy flow, RELATIVE paths] paths built before chdir")
os.chdir(td)
rel = [os.path.relpath(os.path.join(cand, "main.py"), td), os.path.relpath(os.path.join(opp, "main.py"), td)]
os.chdir(os.path.dirname(os.path.join(td, rel[0])))   # legacy chdir into the candidate dir
try:
    make("cabt", configuration={"bo": 3}).run(rel)
    print("ran (unexpected)")
except Exception as e:
    print("FAILS as predicted:", type(e).__name__, str(e)[:90])
os.chdir("/")
shutil.rmtree(td, ignore_errors=True)
