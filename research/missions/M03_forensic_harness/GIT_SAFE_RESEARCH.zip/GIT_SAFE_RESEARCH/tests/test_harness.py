"""Tests for tools/bo3_ab_harness.py.

 * Fake-engine tests need nothing but the standard library (plumbing only -- never evidence of strength).
 * Real-engine tests need `kaggle-environments` (the cabt engine) and are SKIPPED, loudly, when it is missing.
Run from the package root:   python -m unittest tests.test_harness -v
"""
import importlib.util
import json
import os
import queue
import shutil
import sys
import tempfile
import time
import types
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "tests"))
import bo3_ab_harness as H  # noqa: E402
import ptcg_eval_stats as S  # noqa: E402

HAVE_SDK = importlib.util.find_spec("kaggle_environments") is not None


def procs_with(substr):
    """pids whose command line contains substr (Linux /proc)."""
    out = []
    for pid in os.listdir("/proc"):
        if pid.isdigit() and int(pid) != os.getpid():
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as fh:
                    cmd = fh.read().replace(b"\0", b" ").decode("utf-8", "replace")
            except OSError:
                continue
            if substr in cmd:
                out.append(int(pid))
    return out


def fake_tree(td, names=("cand", "ctrl", "opp1", "opp2")):
    for n in names:
        os.makedirs(os.path.join(td, n), exist_ok=True)
        with open(os.path.join(td, n, "main.py"), "w") as fh:
            fh.write("def agent(o):\n    return []\n")


# ------------------------------------------------------------------ D1: the Queue.empty()/is_alive() race
class StubProc:
    def __init__(self, alive, exitcode=0):
        self._alive, self.exitcode, self.pid = alive, exitcode, 999999

    def is_alive(self):
        return self._alive


class RaceQueue:
    """The result lands in the pipe BETWEEN the first read attempt and the liveness check."""

    def __init__(self):
        self.calls = 0
        self.item = {"jid": "x", "ok": True}

    def get(self, timeout=None):
        self.calls += 1
        if self.calls == 1:
            raise queue.Empty
        return self.item

    def empty(self):  # what the legacy harness consulted
        return self.calls == 0


def legacy_poll_step(p, q):
    """Verbatim decision logic of the legacy harness loop (reserch2 bo3_ab_harness.py, main loop)."""
    if not q.empty():
        return "result", q.get()
    elif not p.is_alive():
        return "died", "child exited without result"
    return None, None


class PollRaceTests(unittest.TestCase):
    def test_legacy_logic_loses_the_result(self):
        kind, _ = legacy_poll_step(StubProc(alive=False), RaceQueue())
        self.assertEqual(kind, "died")          # BUG: the finished match is recorded as a crash

    def test_new_logic_recovers_it(self):
        kind, payload = H.poll_child(StubProc(alive=False), RaceQueue(), t0=time.time(), deadline_s=100, drain_s=0.1, get_timeout=0.0)
        self.assertEqual((kind, payload["jid"]), ("result", "x"))

    def test_died_without_result_is_reported(self):
        class Empty:
            def get(self, timeout=None):
                raise queue.Empty
        kind, msg = H.poll_child(StubProc(alive=False, exitcode=-9), Empty(), time.time(), 100, drain_s=0.05, get_timeout=0.0)
        self.assertEqual(kind, "died")
        self.assertIn("rc=-9", msg)

    def test_deadline_kills_group(self):
        killed = []

        class Empty:
            def get(self, timeout=None):
                raise queue.Empty
        kind, _ = H.poll_child(StubProc(alive=True), Empty(), t0=0.0, deadline_s=5.0, get_timeout=0.0, now=lambda: 100.0,
                               kill=lambda p: killed.append(p))
        self.assertEqual(kind, "killed")
        self.assertEqual(len(killed), 1)

    def test_still_running_returns_none(self):
        class Empty:
            def get(self, timeout=None):
                raise queue.Empty
        self.assertEqual(H.poll_child(StubProc(alive=True), Empty(), time.time(), 100, get_timeout=0.0), (None, None))


# ------------------------------------------------------------------ pure helpers
class HelperTests(unittest.TestCase):
    def test_validate_action(self):
        sel = {"option": [{}, {}, {}], "minCount": 1, "maxCount": 2}
        v = H.validate_action
        self.assertEqual(v({"select": sel}, [0], None), ([], []))
        self.assertEqual(v({"select": sel}, [0, 2], None), ([], []))
        self.assertTrue(v({"select": sel}, [], None)[0])               # below minCount
        self.assertTrue(v({"select": sel}, [0, 1, 2], None)[0])        # above maxCount
        self.assertTrue(v({"select": sel}, [3], None)[0])              # out of range
        self.assertTrue(v({"select": sel}, [-1], None)[0])
        self.assertEqual(v({"select": sel}, [1, 1], None)[1], ["duplicate indices"])
        self.assertTrue(v({"select": sel}, "0", None)[0])              # not a list
        self.assertTrue(v({"select": sel}, [True], None)[0])           # bool is not an int action
        deck = [1] * 60
        self.assertEqual(v({"select": None}, deck, {1}), ([], []))
        self.assertTrue(any("60" in x for x in v({"select": None}, deck[:59], {1})[0]))
        self.assertTrue(any("not in the engine card table" in x for x in v({"select": None}, deck[:59] + [1432], {1})[0]))

    def test_outcome_draw_is_not_a_loss_and_none_rewards_fail(self):
        for rewards, want in (([1, -1], "win"), ([-1, 1], "loss"), ([0, 0], "draw"), ([None, -1], "failed")):
            rec = {"a_seat": 0, "rewards": rewards, "failed": False}
            H._outcome(rec)
            self.assertEqual(rec["a_outcome"], want, rewards)

    def test_parse_games_synthetic(self):
        def mk(status, rnd, fp, w0, w1, dr):
            cur = {"round": rnd, "firstPlayer": fp, "draw": dr, "players": [{"win": w0}, {"win": w1}]}
            return types.SimpleNamespace(status=status, observation={"current": cur})
        idle = types.SimpleNamespace(status="INACTIVE", observation={})
        steps = [
            [mk("ACTIVE", 1, -1, 0, 0, 0), idle], [mk("ACTIVE", 1, 0, 0, 0, 0), idle],
            [idle, mk("ACTIVE", 2, -1, 0, 1, 0)], [idle, mk("ACTIVE", 2, 1, 0, 1, 0)],      # p1 won game 1
            [mk("ACTIVE", 3, -1, 1, 1, 0), idle], [mk("ACTIVE", 3, 1, 1, 1, 0), idle],      # p0 won game 2
        ]
        g = H.parse_games(steps, [2, 1, 0])                                                   # p0 won game 3
        self.assertEqual([(x["round"], x["first_player"], x["winner"]) for x in g], [(1, 0, 1), (2, 1, 0), (3, 1, 0)])
        g2 = H.parse_games(steps, [1, 1, 1])                                                  # game 3 drawn
        self.assertEqual(g2[-1]["winner"], "draw")

    def test_relative_paths_are_absolutised(self):
        with tempfile.TemporaryDirectory() as td:
            fake_tree(td)
            old = os.getcwd()
            os.chdir(td)
            try:
                jobs = H.build_jobs("cand", "ctrl", {"o": ("opp1", 1.0)}, 2, 0, "fake", "off", td, 0)
            finally:
                os.chdir(old)
            for j in jobs:
                self.assertTrue(os.path.isabs(j["a_main"]) and os.path.isabs(j["b_main"]), j)
                self.assertTrue(os.path.isfile(j["a_main"]) and os.path.isfile(j["b_main"]))
            self.assertEqual({j["a_seat"] for j in jobs}, {0, 1})                           # seat-swapped


# ------------------------------------------------------------------ fake-engine scheduler/accounting
class FakeRunTests(unittest.TestCase):
    def _run(self, td, matches, deadline=30.0, workers=2, **fake):
        fake_tree(td)
        opps = {"opp1": (os.path.join(td, "opp1"), .6), "opp2": (os.path.join(td, "opp2"), .4)}
        jobs = H.build_jobs(os.path.join(td, "cand"), os.path.join(td, "ctrl"), opps, matches, 3, "fake", "off", td, 0, fake=fake)
        out = os.path.join(td, "r.jsonl")
        res = H.run(jobs, workers, deadline, out, header={"fake": True})
        return jobs, res, out, {k: v[1] for k, v in opps.items()}

    def test_no_lost_jobs_and_clean_exit_code(self):
        with tempfile.TemporaryDirectory() as td:
            jobs, res, out, w = self._run(td, 8, fake_draw_p=0.1)
            self.assertEqual(len(res), len(jobs))
            self.assertEqual(len({r["jid"] for r in res}), len(jobs))
            self.assertEqual(H.report(res, w), 0)
            with self.assertRaises(FileExistsError):                                       # D8: no silent appends
                H.run(jobs[:1], 1, 10, out)

    def test_runtime_failures_fail_the_gate(self):
        with tempfile.TemporaryDirectory() as td:
            jobs, res, out, w = self._run(td, 10, fake_fail_p=0.3)
            self.assertTrue(any(r["failed"] for r in res))
            self.assertEqual(H.report(res, w), 3)

    def test_hang_and_crash_are_contained_and_cleaned_up(self):
        with tempfile.TemporaryDirectory() as td:
            t0 = time.time()
            jobs, res, out, w = self._run(td, 6, deadline=3.0, workers=3, fake_hang_p=0.25, fake_crash_p=0.2)
            kinds = {r.get("failure_kind") for r in res}
            self.assertEqual(len(res), len(jobs))                                          # nothing lost
            self.assertIn("hang_killed", kinds)
            self.assertIn("worker_died", kinds)
            self.assertLess(time.time() - t0, 60)
            time.sleep(0.5)
            self.assertEqual(procs_with("multiprocessing.spawn"), [], "leaked worker processes")
            self.assertEqual(H.report(res, w), 3)

    def test_failed_cells_are_not_renormalised_away(self):
        recs = []
        for i in range(10):
            recs.append(dict(jid=f"cand:a:{i}", arm="cand", label="a", idx=i, a_seat=i % 2, a_cfg="x", failed=False,
                             a_outcome="win" if i % 2 else "loss", rewards=[1, -1], statuses=["DONE", "DONE"], fail_seats={}))
            recs.append(dict(jid=f"cand:b:{i}", arm="cand", label="b", idx=i, a_seat=i % 2, a_cfg="x", failed=True, failure_kind="worker_died",
                             a_outcome="failed", fail_seats={}, rewards=None, statuses=None))
        self.assertEqual(H.report(recs, {"a": .5, "b": .5}), 3)                            # cell b empty -> INCOMPLETE
        with self.assertRaises(S.MissingCellError):
            S.weighted_rate_ci(H.to_stat_cells(H.cells_from_records(recs, "cand")), {"a": .5, "b": .5})

    def test_comparison_csv_schema(self):
        with tempfile.TemporaryDirectory() as td:
            jobs, res, out, w = self._run(td, 6)
            recs, headers = H.load_results([out])
            csv_path = os.path.join(td, "c.csv")
            H.report(recs, w, csv_path, headers)
            rows = open(csv_path).read().strip().splitlines()
            self.assertTrue(rows[0].startswith("candidate_arm,config_hash,opponent_archetype,seat,N_completed,wins,losses,draws"))
            self.assertTrue(any("__FIELD_WEIGHTED_DIFF__" in r for r in rows))


# ------------------------------------------------------------------ REAL engine (kaggle-environments cabt)
@unittest.skipUnless(HAVE_SDK, "kaggle-environments not installed: REAL-ENGINE TESTS NOT RUN")
class RealEngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import agent_fixtures as F
        cls.td = tempfile.mkdtemp(prefix="ptcg_h_")
        cls.A = F.make_agents(cls.td)
        cls.kpath = H.probe_kaggle_path_mode()
        cls.log_dir = os.path.join(cls.td, "logs")
        os.makedirs(cls.log_dir)
        cls.n = 0

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.td, ignore_errors=True)

    def play(self, cand, opp, n=2, deadline=90.0, kpath=None):
        RealEngineTests.n += 1
        jobs = H.build_jobs(cand, None, {"opp": (opp, 1.0)}, n, 11, "real", kpath or self.kpath, self.log_dir, 0, keep_logs=True)
        out = os.path.join(self.td, f"run{RealEngineTests.n}.jsonl")
        return H.run(jobs, 1, deadline, out, header={"t": "real"})

    # --- facts about the build under test
    def test_engine_build_facts(self):
        fp = H.engine_fingerprint()
        self.assertEqual(fp["card_count"], 1431)
        self.assertEqual(fp["card_id_range"], [1, 1431])
        self.assertEqual(fp["cabt_bo_default"], 3)

    # --- cold start exactly like the SDK: exec in a fresh dict => no __file__
    def test_cold_start_without___file__(self):
        bad = self.play(self.A["file_unguarded"], self.A["rand_cwd"], n=2)
        for r in bad:
            self.assertTrue(r["failed"])
            a = str(r["a_seat"])
            self.assertIn("exception", r["fail_seats"][a])
            self.assertIn("NameError", " ".join(r["per_seat"][a]["exception_examples"]))
            self.assertNotIn(str(1 - r["a_seat"]), r["fail_seats"], "opponent must not be blamed")
        ok = self.play(self.A["file_guarded"], self.A["rand_cwd"], n=2)
        for r in ok:
            self.assertFalse(r["failed"], r.get("fail_seats"))
            self.assertIs(r["per_seat"][str(r["a_seat"])]["host"]["has___file__"], False)

    # --- D2: each agent resolves ITS OWN files; same module name in both agents must not collide
    def test_path_isolation_and_module_name_collision(self):
        res = self.play(self.A["helper_x"], self.A["helper_y"], n=4)
        for r in res:
            self.assertFalse(r["failed"], r.get("fail_seats"))
            a = r["a_seat"]
            self.assertEqual(r["decks"][a], self.A["_deck"])
            self.assertEqual(r["decks"][1 - a], self.A["_deck2"])
            self.assertNotEqual(r["decks"][a], r["decks"][1 - a])

    def test_cwd_relative_and_kaggle_path_agents(self):
        res = self.play(self.A["rand_cwd"], self.A["first_kpath"], n=2)
        if self.kpath == "mount":
            for r in res:
                self.assertFalse(r["failed"], r.get("fail_seats"))
        else:  # no bind mount available: must fail LOUDLY, never fall back silently
            for r in res:
                self.assertTrue(r["failed"])
                self.assertIn("FileNotFoundError", " ".join(r["per_seat"][str(1 - r["a_seat"])]["exception_examples"]))

    # --- D6: failure injection + attribution
    def test_exception_is_attributed_to_the_right_agent(self):
        for r in self.play(self.A["crash5"], self.A["rand_cwd"], n=2):
            a = str(r["a_seat"])
            self.assertEqual(list(r["fail_seats"]), [a])
            self.assertIn("exception", r["fail_seats"][a])
            self.assertNotEqual(r["statuses"][int(a)], "DONE")
            self.assertEqual(H.classify(r), "fail_self")
            self.assertEqual(r["a_outcome"], "failed")

    def test_illegal_index_is_detected(self):
        for r in self.play(self.A["illegal3"], self.A["rand_cwd"], n=2):
            ps = r["per_seat"][str(r["a_seat"])]
            self.assertGreaterEqual(ps["illegal"], 1)
            self.assertIn("illegal", r["fail_seats"][str(r["a_seat"])])
            self.assertTrue(any("out of range" in e for e in ps["illegal_examples"]))

    def test_deck_with_id_outside_card_table_fails_loudly(self):
        for r in self.play(self.A["baddeck"], self.A["rand_cwd"], n=2):
            ps = r["per_seat"][str(r["a_seat"])]
            self.assertGreaterEqual(ps["illegal"], 1)
            self.assertTrue(any("not in the engine card table" in e for e in ps["illegal_examples"]), ps["illegal_examples"])
            self.assertTrue(r["failed"])

    def test_sdk_last_callable_trap_is_visible(self):
        r = self.play(self.A["trap"], self.A["rand_cwd"], n=1)[0]
        ps = r["per_seat"][str(r["a_seat"])]
        self.assertEqual(ps["host"]["entry"], "helper_defined_after_agent")      # SDK picked the LAST callable, not `agent`
        self.assertTrue(r["failed"])

    def test_hang_is_killed_and_nothing_leaks(self):
        t0 = time.time()
        r = self.play(self.A["hang3"], self.A["rand_cwd"], n=1, deadline=14.0)[0]
        self.assertEqual(r["failure_kind"], "hang_killed")
        self.assertLess(time.time() - t0, 45)
        time.sleep(0.5)
        self.assertEqual(procs_with("--agent-host"), [], "leaked agent host processes")

    # --- D6: data the gate needs
    def test_game_level_parse_matches_engine_totals(self):
        for r in self.play(self.A["rand_cwd"], self.A["file_guarded"], n=4):
            self.assertFalse(r["failed"], r.get("fail_seats"))
            g, res = r["games"], r["result"]
            self.assertEqual(len(g), sum(res))
            self.assertEqual(sum(1 for x in g if x["winner"] == 0), res[0])
            self.assertEqual(sum(1 for x in g if x["winner"] == 1), res[1])
            self.assertEqual(sum(1 for x in g if x["winner"] == "draw"), res[2])
            self.assertTrue(all(x["first_player"] in (0, 1) for x in g))
            w = 0 if res[0] > res[1] else 1 if res[1] > res[0] else None
            if w is not None:
                self.assertEqual(r["rewards"][w], 1)

    def test_instrumentation_fields(self):
        r = self.play(self.A["rand_cwd"], self.A["file_guarded"], n=1)[0]
        for s in "01":
            ps = r["per_seat"][s]
            self.assertGreater(ps["decisions"], 10)
            for k in ("p50", "p95", "p99", "max"):
                self.assertIsNotNone(ps["rtt_s"][k])
            self.assertGreater(ps["host"]["rss_mb"], 1)
            self.assertEqual(ps["illegal"], 0)
            self.assertEqual(ps["exceptions"], 0)
        self.assertTrue(all(v is not None and 0 < v <= 600 for v in r["overage_min"]))
        self.assertGreater(r["worker_rss_mb"], 1)

    def test_internal_fallback_counters_are_collected(self):
        r = self.play(self.A["counter"], self.A["rand_cwd"], n=1)[0]
        c = r["per_seat"][str(r["a_seat"])]["host"]["counters"]
        self.assertGreater(c.get("FALLBACK_COUNT", 0), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
