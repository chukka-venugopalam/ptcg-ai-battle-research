"""Tests for tools/build_meta_census.py on replays generated LOCALLY by the real cabt engine (official Episodes schema unverified)."""
import csv, importlib.util, json, os, shutil, subprocess, sys, tempfile, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools")); sys.path.insert(0, os.path.join(ROOT, "tests"))
HAVE_SDK = importlib.util.find_spec("kaggle_environments") is not None


@unittest.skipUnless(HAVE_SDK, "kaggle-environments not installed: CENSUS TESTS NOT RUN")
class CensusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import agent_fixtures as F
        from kaggle_environments import make
        cls.td = tempfile.mkdtemp(prefix="ptcg_c_")
        dx, dy = F.sdk_deck(), F.deck_variant(F.sdk_deck())
        cls.dx, cls.dy = dx, dy

        def mk(deck):
            def agent(obs, cfg=None):
                sel = obs["select"]
                if sel is None:
                    return deck
                return list(range(max(sel["minCount"], min(sel["maxCount"], len(sel["option"])))))
            return agent
        cls.draws = 0
        for i in range(6):
            env = make("cabt", configuration={"bo": 3})
            env.run([mk(dx), mk(dy)] if i % 2 == 0 else [mk(dy), mk(dx)])
            json.dump(env.toJSON(), open(os.path.join(cls.td, f"ep{i}.json"), "w"))
            cls.draws += 1 if env.steps[-1][0].reward == 0 else 0

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.td, ignore_errors=True)

    def run_cli(self, src, out, *extra):
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", "build_meta_census.py"), "--episodes", src, "--out", out, *extra],
                           capture_output=True, text=True)
        return r, list(csv.DictReader(open(out)))

    def test_exact_list_census_counts(self):
        r, rows = self.run_cli(self.td, os.path.join(self.td, "out.csv"))
        self.assertEqual(r.returncode, 0, r.stderr)
        st = next(x for x in rows if x["record_type"] == "status")
        self.assertEqual((st["n_episodes_parsed"], st["n_episodes_failed"], st["count_entries"]), ("6", "0", "12"))
        ex = [x for x in rows if x["record_type"] == "exact_list"]
        self.assertEqual(sorted(int(x["count_entries"]) for x in ex), [6, 6])
        self.assertEqual(sum(int(x["wins_in_sample"]) for x in ex), 6 - self.draws)
        arch = [x for x in rows if x["record_type"] == "archetype_heuristic"]
        self.assertTrue(arch and all(x["name"] and x["name"] != "unknown" for x in arch))
        self.assertAlmostEqual(sum(float(x["share_pct"]) for x in arch), 100.0, places=0)

    def test_schema_errors_fail_loudly(self):
        bad = os.path.join(self.td, "bad"); os.makedirs(bad, exist_ok=True)
        json.dump({"nope": 1}, open(os.path.join(bad, "x.json"), "w"))
        shutil.copy(os.path.join(self.td, "ep0.json"), bad)
        r, rows = self.run_cli(bad, os.path.join(self.td, "bad.csv"))
        self.assertEqual(r.returncode, 0)
        self.assertEqual([x["record_type"] for x in rows if x["record_type"] == "schema_error"], ["schema_error"])
        r2, _ = self.run_cli(bad, os.path.join(self.td, "bad2.csv"), "--strict")
        self.assertEqual(r2.returncode, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
