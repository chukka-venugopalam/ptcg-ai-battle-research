"""Tests for tools/submission_audit.py on FIXTURE archives (not your real Bv1/R12 archives -- those were not provided).
Requires kaggle-environments for the engine-backed tests (skipped loudly otherwise).  Run: python -m unittest tests.test_audit -v"""
import argparse
import collections
import contextlib
import importlib.util
import io
import json
import os
import shutil
import sys
import tarfile
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "tests"))
import submission_audit as SA  # noqa: E402
import bo3_ab_harness as H  # noqa: E402

HAVE_SDK = importlib.util.find_spec("kaggle_environments") is not None


def make_tar(src_dir, dest, nested=False, extra=None):
    with tarfile.open(dest, "w:gz") as tf:
        for fn in sorted(os.listdir(src_dir)):
            fp = os.path.join(src_dir, fn)
            if os.path.isfile(fp):
                tf.add(fp, arcname=(os.path.basename(src_dir) + "/" + fn) if nested else fn)
        for name, kind in (extra or []):
            ti = tarfile.TarInfo(name)
            if kind == "symlink":
                ti.type, ti.linkname = tarfile.SYMTYPE, "/etc/passwd"
            else:
                ti.size = 3
            tf.addfile(ti, io.BytesIO(b"bad") if kind != "symlink" else None)
    return dest


def audit_args(archive, work, **kw):
    d = dict(archive=archive, workdir=work, force=False, matches=2, workers=1, baseline=None, deadline=120.0, max_mib=197.7,
             max_p99_s=1.0, max_overage_frac=0.5, kaggle_path="auto", no_engine=False, out=os.path.join(work, "report.json"))
    d.update(kw)
    return argparse.Namespace(**d)


def run_audit(archive, work, **kw):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = SA.cmd_audit(audit_args(archive, work, **kw))
    return rc, json.load(open(os.path.join(work, "report.json"))), buf.getvalue()


class StaticTests(unittest.TestCase):
    def test_static_scan_hints_and_imports(self):
        with tempfile.TemporaryDirectory() as td:
            with open(os.path.join(td, "main.py"), "w") as fh:
                fh.write("import os\nimport numpy as np\nfrom helper import f\nN_POOL = 172\n"
                         "def agent(o):\n    try:\n        x = np.clip(o, 0, 9) % N_POOL\n    except Exception:\n        pass\n"
                         "    return [0]\nBASE = os.path.dirname(__file__)\n")
            open(os.path.join(td, "helper.py"), "w").close()
            rep = SA.static_scan(td)
            keys = " | ".join(rep["risk_hints"])
            for frag in ("clip()", "modulo wrap", "broad except", "uses __file__"):
                self.assertIn(frag, keys)
            self.assertEqual(rep["third_party_imports"], ["numpy"])        # helper is local, os is stdlib

    def test_entry_static_flags_late_callables(self):
        with tempfile.TemporaryDirectory() as td:
            fp = os.path.join(td, "main.py")
            with open(fp, "w") as fh:
                fh.write("def agent(o):\n    return []\ndef _helper():\n    return 1\nfrom math import sqrt\n")
            r = SA.entry_static(fp)
            self.assertTrue(r["agent_defined"])
            self.assertEqual(len(r["callable_bindings_after_agent"]), 2)

    def test_read_deck_csv(self):
        with tempfile.TemporaryDirectory() as td:
            fp = os.path.join(td, "deck.csv")
            open(fp, "w").write("card_id\n" + "\n".join(["3"] * 60))
            ids, problems = SA.read_deck_csv(fp)
            self.assertEqual(len(ids), 60)
            self.assertTrue(any("non-integer" in p for p in problems))

    def test_tar_safety_detection(self):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "s")
            os.makedirs(src)
            open(os.path.join(src, "main.py"), "w").write("def agent(o): return []\n")
            open(os.path.join(src, "deck.csv"), "w").write("3\n")
            tar = make_tar(src, os.path.join(td, "evil.tar.gz"), extra=[("../evil.txt", "file"), ("/abs.txt", "file"), ("link", "symlink")])
            rep = SA.tar_report(tar, 197.7)
            txt = " | ".join(rep["problems"])
            for frag in ("path traversal", "absolute path", "symlink"):
                self.assertIn(frag, txt)
            with self.assertRaises(ValueError):
                SA.safe_extract(tar, os.path.join(td, "x"))

    def test_nested_folder_and_missing_root_files(self):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "agent_dir")
            os.makedirs(src)
            open(os.path.join(src, "main.py"), "w").write("def agent(o): return []\n")
            open(os.path.join(src, "deck.csv"), "w").write("3\n")
            rep = SA.tar_report(make_tar(src, os.path.join(td, "n.tar.gz"), nested=True), 197.7)
            self.assertTrue(any("main.py not at archive root" in p and "nested" in p for p in rep["problems"]))

    def test_size_limit(self):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "s")
            os.makedirs(src)
            open(os.path.join(src, "main.py"), "w").write("x=1\n")
            open(os.path.join(src, "deck.csv"), "w").write("3\n")
            rep = SA.tar_report(make_tar(src, os.path.join(td, "a.tar.gz")), max_mib=0.0000001)
            self.assertTrue(any("size" in p for p in rep["problems"]))

    def test_extraction_requires_clean_dir(self):
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "s")
            os.makedirs(src)
            open(os.path.join(src, "main.py"), "w").write("x=1\n")
            tar = make_tar(src, os.path.join(td, "a.tar.gz"))
            os.makedirs(os.path.join(td, "dirty"))
            with self.assertRaises(FileExistsError):
                SA.safe_extract(tar, os.path.join(td, "dirty"))

    def test_npz_scan_flags_small_embedding_tables(self):
        try:
            import numpy as np
        except ImportError:
            self.skipTest("numpy missing")
        with tempfile.TemporaryDirectory() as td:
            np.savez(os.path.join(td, "w.npz"), card_emb=np.zeros((1267, 4)), other=np.zeros((3,)))
            r = SA.npz_scan(td, [3, 1431, 1219])
            flags = [f for e in r["arrays"] for f in e.get("flags", [])]
            self.assertTrue(any("rows=1267 <= max deck id 1431" in f for f in flags), flags)


class DiffTests(unittest.TestCase):
    def test_diff_reports_constants_deck_and_files(self):
        with tempfile.TemporaryDirectory() as td:
            a, b = os.path.join(td, "a"), os.path.join(td, "b")
            for d in (a, b):
                os.makedirs(d)
            open(os.path.join(a, "main.py"), "w").write("THRESH = 0.5\nUSE_RULE = False\ndef agent(o):\n    return []\n")
            open(os.path.join(b, "main.py"), "w").write("THRESH = 0.6\nUSE_RULE = True\ndef agent(o):\n    return []\n# patched\n")
            open(os.path.join(a, "deck.csv"), "w").write("\n".join(["3"] * 58 + ["1", "1"]))
            open(os.path.join(b, "deck.csv"), "w").write("\n".join(["3"] * 56 + ["1"] * 4))
            open(os.path.join(b, "extra.txt"), "w").write("x")
            d = SA.diff_pair(a, b)
            self.assertEqual(d["only_in_b"], ["extra.txt"])
            ch = {c["file"]: c for c in d["changed"]}
            self.assertEqual(ch["main.py"]["constant_changes"], {"THRESH": ("0.5", "0.6"), "USE_RULE": ("False", "True")})
            self.assertEqual(ch["main.py"]["added_lines"], 3)
            self.assertIn("3", " ".join(ch["deck.csv"]["deck_multiset_diff"]))

    def test_identical_trees(self):
        with tempfile.TemporaryDirectory() as td:
            a, b = os.path.join(td, "a"), os.path.join(td, "b")
            for d in (a, b):
                os.makedirs(d)
                open(os.path.join(d, "main.py"), "w").write("x=1\n")
            d = SA.diff_pair(a, b)
            self.assertEqual((d["changed"], d["only_in_a"], d["only_in_b"]), ([], [], []))


@unittest.skipUnless(HAVE_SDK, "kaggle-environments not installed: ENGINE-BACKED AUDIT TESTS NOT RUN")
class EngineBackedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import agent_fixtures as F
        cls.F = F
        cls.td = tempfile.mkdtemp(prefix="ptcg_a_")
        cls.A = F.make_agents(os.path.join(cls.td, "agents"))

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.td, ignore_errors=True)

    def tar(self, name):
        return make_tar(self.A[name], os.path.join(self.td, name + ".tar.gz"))

    def test_good_fixture_archive_passes_safety_gate(self):
        tar = self.tar("file_guarded")
        rc, rep, out = run_audit(tar, os.path.join(self.td, "w_good"))
        self.assertEqual(rc, 0, out)
        self.assertEqual(rep["archive_report"]["sha256"], H.sha256_file(tar))
        self.assertEqual(sum(r["count"] for r in rep["deck_audit"]["table"]), 60)
        self.assertTrue(all(r["name"] for r in rep["deck_audit"]["table"]))
        cs = rep["cold_start"]
        self.assertTrue(cs["ok"] and cs["equals_deck_csv"] and cs["entry_is_agent"])
        self.assertIs(cs["main_globals_have___file__"], False)
        self.assertEqual(rep["matches"]["completed"], 2)
        self.assertEqual(rep["matches"]["illegal"] + rep["matches"]["exceptions"], 0)
        self.assertIsNotNone(rep["matches"]["agent_s"]["p99"])
        self.assertIn("VERDICT: PASS", out)

    def test_nested_archive_fails_gate_without_running_matches(self):
        src = self.A["file_guarded"]
        tar = make_tar(src, os.path.join(self.td, "nested.tar.gz"), nested=True)
        rc, rep, out = run_audit(tar, os.path.join(self.td, "w_nested"), no_engine=True)
        self.assertEqual(rc, 2)
        self.assertFalse(rep["safety_gate"][0]["passed"])

    def test_last_callable_trap_fails_cold_start(self):
        rc, rep, out = run_audit(self.tar("trap"), os.path.join(self.td, "w_trap"), matches=1)
        self.assertEqual(rc, 2)
        self.assertEqual(rep["cold_start"]["entrypoint_resolved_by_sdk_rule"], "helper_defined_after_agent")
        self.assertTrue(rep["entry_static"]["callable_bindings_after_agent"])

    def test_agent_returning_unknown_id_fails_cold_start(self):
        # deck.csv is legal but the agent builds a different deck in code: the PLAYED deck is the first-call response
        rc, rep, out = run_audit(self.tar("baddeck"), os.path.join(self.td, "w_bad"), matches=1)
        self.assertEqual(rc, 2)
        self.assertFalse(rep["cold_start"]["ok"])
        self.assertFalse(rep["cold_start"]["equals_deck_csv"])
        self.assertTrue(any("not in the engine card table" in v for v in rep["cold_start"]["validation"]), rep["cold_start"])

    def test_deck_csv_with_unknown_id_fails(self):
        src = os.path.join(self.td, "badcsv")
        shutil.copytree(self.A["file_guarded"], src)
        ids = self.A["_deck"][:-1] + [1432]
        open(os.path.join(src, "deck.csv"), "w").write("\n".join(map(str, ids)) + "\n")
        rc, rep, out = run_audit(make_tar(src, os.path.join(self.td, "badcsv.tar.gz")), os.path.join(self.td, "w_badcsv"), no_engine=False, matches=1)
        self.assertEqual(rc, 2)
        self.assertTrue(any("NOT in the engine card table" in p for p in rep["deck_audit"]["problems"]))

    def test_unsafe_archive_is_never_extracted(self):
        src = self.A["file_guarded"]
        tar = make_tar(src, os.path.join(self.td, "evil.tar.gz"), extra=[("../escape.txt", "file")])
        rc, rep, out = run_audit(tar, os.path.join(self.td, "w_evil"), no_engine=True)
        self.assertEqual(rc, 2)
        self.assertFalse(os.path.exists(os.path.join(self.td, "w_evil", "extracted")))

    def test_rule_checker_agrees_with_the_engine(self):
        """Every rule my audit enforces must match what the real engine does (probed empirically)."""
        cards = H.r2_card_table()[0]
        by_id = {c["cardId"]: c for c in cards}
        deck = self.A["_deck"]
        names = collections.defaultdict(list)
        for c in cards:
            if c["cardType"] == 0:
                names[c["name"]].append(c["cardId"])
        dup_name = next(n for n, ids in names.items() if len(ids) >= 2 and by_id[ids[0]]["basic"])
        i1, i2 = names[dup_name][:2]
        aces = [c["cardId"] for c in cards if c["aceSpec"]][:2]
        energy3 = deck.index(3)
        cases = {
            "sample deck": (deck, True),
            "5 copies of one id": ([1121] * 5 + [3] * 55, False),
            "5 copies of one NAME across 2 ids (3+2)": ([i1] * 3 + [i2] * 2 + [3] * 55, False),
            "4 copies of one NAME across 2 ids (2+2)": ([i1] * 2 + [i2] * 2 + [3] * 56, True),
            "no Basic Pokemon": ([1121] * 4 + [1092] * 1 + [3] * 55, False),
            "2 ACE SPEC (different cards)": ([aces[0], aces[1]] + [i1] * 1 + [3] * 57, False),
            "unknown id 1432": (deck[:-1] + [1432], False),
            "id 0": (deck[:-1] + [0], False),
        }
        for label, (ids, expect_ok) in cases.items():
            rep = SA.deck_audit(ids)
            rules_ok = not rep["problems"]
            self.assertEqual(rules_ok, expect_ok, f"{label}: audit problems={rep['problems']}")
            if rep["rules_checked"]:
                self.assertEqual(rep["engine_accepts"], expect_ok, f"{label}: engine disagrees with expectation")

    def test_diff_of_two_archives(self):
        a, b = self.tar("helper_x"), self.tar("helper_y")
        with tempfile.TemporaryDirectory() as td:
            args = argparse.Namespace(paths=[a, b], max_lines=50, out=os.path.join(td, "d.json"))
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(SA.cmd_diff(args), 0)
            rep = json.load(open(args.out))
            changed = {c["file"] for c in rep["comparisons"][0]["changed"]}
            self.assertEqual(changed, {"deck.csv", "helper.py"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
