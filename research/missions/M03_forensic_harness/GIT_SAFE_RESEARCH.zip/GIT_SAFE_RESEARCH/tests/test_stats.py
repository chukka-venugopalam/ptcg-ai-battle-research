"""Tests for tools/ptcg_eval_stats.py.  Run:  python -m unittest tests.test_stats -v   (from the package root)"""
import importlib.util
import math
import os
import random
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import ptcg_eval_stats as S  # noqa: E402


def _load_legacy(name, fname):
    path = os.path.join(ROOT, "legacy", fname)
    if not os.path.exists(path):
        return None
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


class SprtTests(unittest.TestCase):
    def test_regression_sign_required_by_mission(self):
        # 10/100 wins strongly SUPPORTS a 45% win-rate regression hypothesis against a 50% baseline
        llr, lo, up, dec = S.sprt(10, 100, 0.50, 0.45)
        self.assertGreater(llr, up)
        self.assertEqual(dec, "accept H1")
        # 70/100 wins CONTRADICTS that regression
        llr, lo, up, dec = S.sprt(70, 100, 0.50, 0.45)
        self.assertLess(llr, lo)
        self.assertEqual(dec, "accept H0")

    def test_improvement_direction_unchanged(self):
        self.assertEqual(S.sprt(70, 100, 0.50, 0.55)[3], "accept H1")
        self.assertEqual(S.sprt(10, 100, 0.50, 0.55)[3], "accept H0")
        self.assertEqual(S.sprt(50, 100, 0.50, 0.55)[3], "continue")

    def test_llr_is_the_log_likelihood_ratio_for_both_directions(self):
        rnd = random.Random(5)
        for _ in range(200):
            n = rnd.randint(1, 400)
            k = rnd.randint(0, n)
            p0, p1 = rnd.uniform(.2, .8), rnd.uniform(.2, .8)
            if abs(p0 - p1) < 1e-3:
                continue
            ll = lambda p: k * math.log(p) + (n - k) * math.log(1 - p)  # noqa: E731
            self.assertAlmostEqual(S.sprt(k, n, p0, p1)[0], ll(p1) - ll(p0), places=9)

    def test_operating_characteristics_regression_test(self):
        # H0: p=.50 vs H1: p=.45 (regression). If the truth is .45 we must usually accept H1; if .50, rarely.
        bad = S.sprt_simulate(0.45, 0.50, 0.45, n_sims=800, seed=1)
        ok = S.sprt_simulate(0.50, 0.50, 0.45, n_sims=800, seed=2)
        self.assertGreater(bad["p_accept_h1"], 0.90)
        self.assertLess(ok["p_accept_h1"], 0.08)

    def test_expected_n_close_to_simulation(self):
        sim = S.sprt_simulate(0.55, 0.50, 0.55, n_sims=1500, seed=3)
        wald = S.sprt_expected_n(0.50, 0.55)
        self.assertLess(abs(sim["mean_n"] - wald) / wald, 0.12)
        self.assertGreater(sim["p_accept_h1"], 0.92)

    def test_report_claim_590_is_not_reproduced(self):
        # NEXT_SUBMISSION_PLAN.md: "SPRT ... averages ~590 matches vs 1,294 fixed".  Wald/sim give ~530; the matching
        # fixed-N comparator (one-sided alpha=beta=.05) is 1077, not 1294 (that number is two-sided alpha, 95% power).
        self.assertLess(S.sprt_expected_n(0.5, 0.55), 560)
        self.assertEqual(S.n_one_sample(.55, .5, alpha=.05, power=.95, sides=1), 1077)
        self.assertEqual(S.n_one_sample(.55, .5, alpha=.05, power=.95, sides=2), 1294)

    def test_legacy_sprt_bug_is_locked_in(self):
        legacy = _load_legacy("legacy_stats", "ptcg_eval_stats.legacy.py")
        if legacy is None:
            self.skipTest("legacy copy not present")
        self.assertEqual(legacy.sprt(10, 100, .5, .45)[3], "accept H0")   # WRONG (should be accept H1)
        self.assertEqual(legacy.sprt(70, 100, .5, .45)[3], "accept H1")   # WRONG (should be accept H0)

    def test_input_validation(self):
        for bad in ((10, 100, .5, .5), (10, 100, 0, .5), (10, 100, .5, 1.0)):
            with self.assertRaises(ValueError):
                S.sprt(*bad)
        with self.assertRaises(ValueError):
            S.sprt(101, 100, .5, .55)


class SidednessTests(unittest.TestCase):
    def test_two_modules_reconcile(self):
        self.assertEqual(S.n_one_sample(.55, .5, alpha=.05, sides=2), 783)      # reserch2 ptcg_eval_stats (two-sided)
        self.assertEqual(S.n_one_sample(.55, .5, alpha=.05, sides=1), 617)      # reserch1 stats_gates (one-sided)
        legacy_gates = _load_legacy("legacy_gates", "stats_gates.legacy.py")
        if legacy_gates is not None:
            self.assertEqual(legacy_gates.required_games(0.05), S.n_one_sample(.55, .5, alpha=.05, sides=1))
        legacy_stats = _load_legacy("legacy_stats2", "ptcg_eval_stats.legacy.py")
        if legacy_stats is not None:
            self.assertEqual(legacy_stats.n_one_sample(.55), S.n_one_sample(.55))
            self.assertEqual(legacy_stats.n_two_sample(.55, .5), S.n_two_sample(.55, .5))

    def test_preregistered_convention(self):
        self.assertEqual((S.PREREG["alpha_total"], S.PREREG["sides"]), (0.05, 2))
        # two-sided total alpha .05 <=> one-sided .025  (lower end of a 95% CI)
        self.assertEqual(S.n_one_sample(.55, .5, alpha=.05, sides=2), S.n_one_sample(.55, .5, alpha=.025, sides=1))

    def test_legacy_gate_has_about_half_power_at_true_55(self):
        for n in (500, 800, 1000, 1500):
            self.assertTrue(0.45 < S.gate_power(n, .55) < 0.56, (n, S.gate_power(n, .55)))
        self.assertGreater(S.gate_power(500, .60), 0.95)

    def test_report_power_table_reproduced(self):
        self.assertAlmostEqual(S.mdes_one_sample(300), 0.581, places=3)
        self.assertAlmostEqual(S.mdes_two_sample(300), 0.613, places=3)
        self.assertAlmostEqual(S.mdes_two_sample(1000), 0.562, places=3)
        self.assertTrue(4300 < S.n_two_sample(.53, .50) < 4400)


class StrictCellTests(unittest.TestCase):
    W = {"a": .5, "b": .3, "c": .2}

    def test_missing_cell_raises_instead_of_renormalising(self):
        with self.assertRaises(S.MissingCellError):
            S.weighted_rate({"a": (5, 10), "b": (4, 10)}, self.W)
        with self.assertRaises(S.MissingCellError):
            S.weighted_rate({"a": (5, 10), "b": (4, 10), "c": (0, 0)}, self.W)

    def test_allow_missing_reports_missing_mass(self):
        r = S.weighted_rate_ci({"a": (5, 10), "b": (4, 10)}, self.W, allow_missing=True)
        self.assertTrue(r["incomplete"])
        self.assertAlmostEqual(r["missing_mass"], 0.2, places=9)
        self.assertEqual(r["missing"], ["c"])

    def test_diff_requires_both_arms_complete(self):
        full = {"a": (6, 10), "b": (5, 10), "c": (5, 10)}
        with self.assertRaises(S.MissingCellError):
            S.weighted_diff_ci(full, {"a": (5, 10), "b": (5, 10)}, self.W)

    def test_bad_cell_rejected(self):
        with self.assertRaises(ValueError):
            S.weighted_rate_ci({"a": (11, 10)}, {"a": 1.0})


class IntervalTests(unittest.TestCase):
    def test_single_stratum_equals_newcombe(self):
        r = S.weighted_diff_ci({"x": (60, 100)}, {"x": (50, 100)}, {"x": 1.0})
        lo, hi = S.newcombe_diff(60, 100, 50, 100)
        self.assertAlmostEqual(r["lo"], lo, places=12)
        self.assertAlmostEqual(r["hi"], hi, places=12)

    def test_single_stratum_equals_wilson(self):
        r = S.weighted_rate_ci({"x": (60, 100)}, {"x": 1.0})
        lo, hi = S.wilson(60, 100)
        self.assertAlmostEqual(r["lo"], lo, places=12)
        self.assertAlmostEqual(r["hi"], hi, places=12)

    def test_antisymmetry(self):
        c = {"a": (60, 100), "b": (45, 90)}
        k = {"a": (50, 100), "b": (50, 95)}
        w = {"a": .6, "b": .4}
        d1, d2 = S.weighted_diff_ci(c, k, w), S.weighted_diff_ci(k, c, w)
        self.assertAlmostEqual(d1["diff"], -d2["diff"], places=12)
        self.assertAlmostEqual(d1["lo"], -d2["hi"], places=12)
        self.assertAlmostEqual(d1["hi"], -d2["lo"], places=12)

    def test_cand_rate_ci_and_diff_ci_are_different_objects(self):
        c = {"a": (600, 1000), "b": (500, 1000)}
        k = {"a": (500, 1000), "b": (500, 1000)}
        w = {"a": .5, "b": .5}
        single = S.weighted_rate_ci(c, w)
        diff = S.weighted_diff_ci(c, k, w)
        self.assertGreater(diff["hi"] - diff["lo"], single["hi"] - single["lo"])  # difference of two noisy arms is wider

    def test_coverage_of_weighted_diff_and_rate(self):
        """Empirical coverage of the stratified MOVER intervals (nominal 95%) on a realistic design:
        6 archetypes x 2 seats, unequal weights, win rates 0.35-0.65."""
        rnd = random.Random(12345)
        arch_w = {"a": .30, "b": .22, "c": .17, "d": .14, "e": .10, "f": .07}
        strata = {(a, s): w / 2 for a, w in arch_w.items() for s in (0, 1)}
        p_c = {k: v for k, v in zip(strata, [.62, .58, .50, .47, .55, .66, .40, .45, .52, .50, .60, .35])}
        p_k = {k: min(.95, max(.05, p_c[k] - d)) for k, d in zip(strata, [.03] * 12)}
        n_each = 70
        true_diff = sum(strata[k] * (p_c[k] - p_k[k]) for k in strata)
        true_rate = sum(strata[k] * p_c[k] for k in strata)
        cover_d = cover_r = 0
        sims = 1200
        binom = lambda n, p: sum(rnd.random() < p for _ in range(n))  # noqa: E731
        for _ in range(sims):
            cc = {k: (binom(n_each, p_c[k]), n_each) for k in strata}
            kk = {k: (binom(n_each, p_k[k]), n_each) for k in strata}
            d = S.weighted_diff_ci(cc, kk, strata)
            cover_d += d["lo"] <= true_diff <= d["hi"]
            r = S.weighted_rate_ci(cc, strata)
            cover_r += r["lo"] <= true_rate <= r["hi"]
        self.assertTrue(0.925 <= cover_d / sims <= 0.985, cover_d / sims)
        self.assertTrue(0.925 <= cover_r / sims <= 0.985, cover_r / sims)

    def test_bootstrap_agrees_with_mover(self):
        c = {"a": (320, 500), "b": (250, 500)}
        k = {"a": (300, 500), "b": (240, 500)}
        w = {"a": .6, "b": .4}
        m = S.weighted_diff_ci(c, k, w)
        pt, lo, hi = S.weighted_diff_bootstrap(c, k, w, n_boot=3000, seed=4)
        self.assertAlmostEqual(pt, m["diff"], places=9)
        self.assertLess(abs(lo - m["lo"]), 0.012)
        self.assertLess(abs(hi - m["hi"]), 0.012)

    def test_mantel_haenszel_matches_hand_computation(self):
        strata = [(10, 20, 5, 25), (15, 15, 10, 20)]
        R = sum(a * d / (a + b + c + d) for a, b, c, d in strata)
        Sx = sum(b * c / (a + b + c + d) for a, b, c, d in strata)
        mh = S.mantel_haenszel(strata)
        self.assertAlmostEqual(mh["or"], R / Sx, places=12)
        self.assertTrue(mh["lo"] < mh["or"] < mh["hi"])


class GateTests(unittest.TestCase):
    W = {"a": .4, "b": .3, "c": .2, "d": .1}

    @staticmethod
    def cells(rates, n):
        return {k: (round(r * n), n) for k, r in rates.items()}

    def test_confirm_passes_clear_improvement(self):
        c = self.cells({"a": .60, "b": .58, "c": .60, "d": .58}, 400)
        k = self.cells({"a": .50, "b": .50, "c": .50, "d": .50}, 400)
        g = S.gate_confirm(c, k, self.W)
        self.assertTrue(g["passed"], g["checks"])

    def test_confirm_fails_on_too_few_matches(self):
        c = self.cells({"a": .60, "b": .58, "c": .60, "d": .58}, 200)
        k = self.cells({"a": .50, "b": .50, "c": .50, "d": .50}, 200)
        g = S.gate_confirm(c, k, self.W)
        self.assertFalse(g["passed"])
        self.assertFalse(g["checks"][0][1])

    def test_confirm_fails_on_archetype_regression_even_if_field_improves(self):
        c = self.cells({"a": .75, "b": .62, "c": .35, "d": .62}, 500)
        k = self.cells({"a": .50, "b": .50, "c": .50, "d": .50}, 500)
        g = S.gate_confirm(c, k, self.W)
        self.assertFalse(g["passed"])
        self.assertFalse(g["checks"][2][1], g["checks"])

    def test_confirm_fails_when_ci_straddles_zero(self):
        c = self.cells({"a": .52, "b": .52, "c": .52, "d": .52}, 300)
        k = self.cells({"a": .50, "b": .50, "c": .50, "d": .50}, 300)
        g = S.gate_confirm(c, k, self.W, min_matches_per_arm=1000)
        self.assertFalse(g["passed"])

    def test_confirm_raises_on_missing_cell(self):
        c = self.cells({"a": .6, "b": .6, "c": .6}, 400)
        k = self.cells({"a": .5, "b": .5, "c": .5, "d": .5}, 400)
        with self.assertRaises(S.MissingCellError):
            S.gate_confirm(c, k, self.W)

    def test_screen_rejects_regression_only(self):
        k = self.cells({"a": .50, "b": .50, "c": .50, "d": .50}, 100)
        bad = self.cells({"a": .44, "b": .45, "c": .46, "d": .44}, 100)
        fine = self.cells({"a": .50, "b": .51, "c": .49, "d": .50}, 100)
        self.assertFalse(S.gate_screen(bad, k, self.W)["passed"])
        self.assertTrue(S.gate_screen(fine, k, self.W)["passed"])
        one_bad = self.cells({"a": .30, "b": .52, "c": .52, "d": .52}, 100)
        self.assertFalse(S.gate_screen(one_bad, k, self.W)["passed"])


class MiscTests(unittest.TestCase):
    def test_bo3_roundtrip(self):
        for p in (.4, .5, .55, .7):
            self.assertAlmostEqual(S.game_from_bo3(S.bo3_from_game(p)), p, places=9)

    def test_selftest_runs(self):
        S._selftest()


if __name__ == "__main__":
    unittest.main(verbosity=2)
