# GIT_SAFE_RESEARCH — Pokémon TCG Playground, Mission 3 (2026-10-15)

Authored scripts, tests, reports and hashes only. **Not included:** engine binaries, the SDK wheel, any card database/table, episode data or replays, submission archives, third-party agents/weights.
(Card ids appear only as literals inside tests; names and tables are read at run time from the SDK you install.)

Start with `DECISION_REPORT.md` (decision: **preserve Bv1, upload nothing**), then `FORENSIC_FINDINGS.md`, then `HARNESS_AUDIT_AND_TESTS.md`.

| Path | What |
|---|---|
| `DECISION_REPORT.md`, `FORENSIC_FINDINGS.md`, `HARNESS_AUDIT_AND_TESTS.md` | the three reports |
| `CURRENT_META_REBUILT.csv` | **not rebuilt** (no official episodes reachable); carries the reports' third-party panel tagged `reported` |
| `CANDIDATE_COMPARISON.csv` | all rows `NOT RUN` (archives/replays not provided) |
| `tools/ptcg_eval_stats.py` | repaired statistics (SPRT sign fix, explicit sidedness, strict cells, stratified difference CI, executable gates) |
| `tools/bo3_ab_harness.py` | repaired real-engine BO3 harness (`run` / `compare` / `selftest`; `--engine fake` = plumbing only) |
| `tools/submission_audit.py` | `audit` (identity, tar safety, deck vs engine, cold start, safety gate) and `diff` |
| `tools/build_meta_census.py` | replay → exact-list/archetype census (official schema unverified; fails loudly) |
| `tools/fetch_kaggle_evidence.sh` | read-only Kaggle CLI collection (**NOT RUN**) |
| `tests/` | 77 tests (stats 31, harness 14 + 12 real-engine, audit 18, census 2) |
| `legacy/` | unmodified copies of the three superseded modules from your research ZIPs (for the defect demos) |
| `evidence/` | test logs, fake self-test, real-engine smoke output (plumbing only), input SHA-256 inventory, legacy-defect demo |

## Run

```bash
# fake/pure tests need only Python >= 3.9
python -m unittest tests.test_stats tests.test_harness.PollRaceTests tests.test_harness.HelperTests tests.test_harness.FakeRunTests
# real engine (tested: Python 3.12, Linux, root for the per-agent /kaggle_simulations/agent bind mount)
python -m venv v && v/bin/pip install --no-deps kaggle-environments==1.33.0 && v/bin/pip install jsonschema requests pyjson5 termcolor numpy
v/bin/python -W ignore -m unittest discover -s tests -t . -v
v/bin/python tools/submission_audit.py audit submission_Bv1_backup_826.tar.gz --matches 20 --out bv1_audit.json
v/bin/python tools/bo3_ab_harness.py run --cand ./cand --control ./bv1 --opp name=./pilot:0.2 --matches 100 --workers 2 --gate screen --out run1.jsonl
```
Exit codes: `0` ok · `2` audit safety gate failed · `3` runtime failure / incomplete cell · `4` lost jobs · `5` gate failed.
