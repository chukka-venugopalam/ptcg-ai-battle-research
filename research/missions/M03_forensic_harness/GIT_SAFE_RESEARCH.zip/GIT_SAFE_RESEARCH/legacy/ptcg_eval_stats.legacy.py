#!/usr/bin/env python3
"""ptcg_eval_stats.py -- statistics helpers for PTCG-ladder candidate evaluation.

Pure standard library (Python >= 3.9). No numpy/scipy required.

    python ptcg_eval_stats.py --selftest   # reproduces published Wilson/z numbers, checks BT + MH
    python ptcg_eval_stats.py --tables     # prints the power / rating-noise tables used in the audit

What this module is for
  * Wilson intervals, two-proportion tests, Newcombe CI for a difference
  * sample-size / minimum-detectable-effect (MDES) calculators
  * BO3 <-> single-game win-probability conversion
  * rating-scale conversions (Elo-400 vs probit-beta-100) and episodes-needed-to-resolve-a-rating-gap
  * SPRT boundaries, Bradley-Terry fit (MM algorithm), Mantel-Haenszel stratified comparison

It does NOT know anything about the cabt engine and never touches Kaggle.
"""
from __future__ import annotations

import argparse
import math
import random
from statistics import NormalDist
from typing import Dict, List, Sequence, Tuple

_N = NormalDist()
Z95 = _N.inv_cdf(0.975)


# --------------------------------------------------------------------------- intervals / tests
def wilson(k: int, n: int, z: float = Z95) -> Tuple[float, float]:
    """Wilson score interval for a binomial proportion."""
    if n <= 0 or not (0 <= k <= n):
        raise ValueError("need n > 0 and 0 <= k <= n")
    p = k / n
    d = 1.0 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def two_prop_z(k1: int, n1: int, k2: int, n2: int) -> Tuple[float, float, float]:
    """Pooled two-proportion z-test. Returns (diff, z, two-sided p)."""
    p1, p2 = k1 / n1, k2 / n2
    pp = (k1 + k2) / (n1 + n2)
    se = math.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2))
    z = (p1 - p2) / se if se > 0 else 0.0
    return p1 - p2, z, 2 * (1 - _N.cdf(abs(z)))


def newcombe_diff(k1: int, n1: int, k2: int, n2: int, z: float = Z95) -> Tuple[float, float]:
    """Newcombe (1998) hybrid-score CI for p1 - p2 (independent samples)."""
    l1, u1 = wilson(k1, n1, z)
    l2, u2 = wilson(k2, n2, z)
    p1, p2 = k1 / n1, k2 / n2
    d = p1 - p2
    return (d - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2),
            d + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2))


def binom_two_sided_p(k: int, n: int, p0: float = 0.5) -> float:
    """Exact two-sided binomial test (sum of pmf <= observed pmf)."""
    def logpmf(i: int) -> float:
        return (math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
                + i * math.log(p0) + (n - i) * math.log(1 - p0))
    lo = logpmf(k) + 1e-12
    return min(1.0, sum(math.exp(logpmf(i)) for i in range(n + 1) if logpmf(i) <= lo))


# --------------------------------------------------------------------------- sample size / MDES
def n_one_sample(p1: float, p0: float = 0.5, alpha: float = 0.05, power: float = 0.80) -> int:
    """Games needed to detect true win rate p1 vs a known p0 (two-sided alpha)."""
    za, zb = _N.inv_cdf(1 - alpha / 2), _N.inv_cdf(power)
    num = za * math.sqrt(p0 * (1 - p0)) + zb * math.sqrt(p1 * (1 - p1))
    return math.ceil((num / (p1 - p0)) ** 2)


def n_two_sample(p1: float, p2: float, alpha: float = 0.05, power: float = 0.80) -> int:
    """Games PER ARM to detect p1 vs p2 with independent samples (two-sided alpha)."""
    za, zb = _N.inv_cdf(1 - alpha / 2), _N.inv_cdf(power)
    pb = (p1 + p2) / 2
    num = za * math.sqrt(2 * pb * (1 - pb)) + zb * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))
    return math.ceil((num / (p1 - p2)) ** 2)


def _mdes(n: int, fn, p0: float) -> float:
    lo, hi = p0 + 1e-6, 0.999
    for _ in range(80):
        mid = (lo + hi) / 2
        if fn(mid) <= n:
            hi = mid
        else:
            lo = mid
    return hi


def mdes_one_sample(n: int, p0: float = 0.5, alpha: float = 0.05, power: float = 0.80) -> float:
    """Smallest true win rate (> p0) detectable with n games vs fixed p0."""
    return _mdes(n, lambda p1: n_one_sample(p1, p0, alpha, power), p0)


def mdes_two_sample(n_per_arm: int, p0: float = 0.5, alpha: float = 0.05, power: float = 0.80) -> float:
    """Smallest p1 (> p0) distinguishable from p0 with n_per_arm games in each of two independent arms."""
    return _mdes(n_per_arm, lambda p1: n_two_sample(p1, p0, alpha, power), p0)


# --------------------------------------------------------------------------- BO3 and rating scales
def bo3_from_game(p: float) -> float:
    """P(win best-of-3) if games are i.i.d. with win prob p (ignores first-player effects)."""
    return p * p * (3 - 2 * p)


def game_from_bo3(m: float) -> float:
    lo, hi = 0.0, 1.0
    for _ in range(80):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if bo3_from_game(mid) < m else (lo, mid)
    return (lo + hi) / 2


def elo_p(delta: float, scale: float = 400.0) -> float:
    return 1.0 / (1.0 + 10 ** (-delta / scale))


def probit_p(delta: float, beta: float = 100.0) -> float:
    """TrueSkill-style: P(win) = Phi(delta / (sqrt(2) * beta))."""
    return _N.cdf(delta / (math.sqrt(2) * beta))


def rating_se(n: int, model: str = "elo400") -> float:
    """SE (rating points) of a performance-rating estimate from n games vs ~equal-rated opponents (p ~ 0.5)."""
    if model == "elo400":
        return 2 * (400 / math.log(10)) / math.sqrt(n)
    if model == "probit100":
        slope = _N.pdf(0) / (math.sqrt(2) * 100)
        return 0.5 / math.sqrt(n) / slope
    raise ValueError(model)


def episodes_to_resolve(gap: float, model: str = "elo400", z: float = Z95) -> int:
    """Episodes EACH of two submissions needs before a rating gap of `gap` points is ~z-sigma significant."""
    se1 = rating_se(1, model)
    return math.ceil((z * math.sqrt(2) * se1 / gap) ** 2)


# --------------------------------------------------------------------------- sequential testing
def sprt(k: int, n: int, p0: float, p1: float, alpha: float = 0.05, beta: float = 0.05):
    """Wald SPRT for H0: p=p0 vs H1: p=p1 (p1 > p0 or p1 < p0). Returns (llr, lower, upper, decision)."""
    llr = k * math.log(p1 / p0) + (n - k) * math.log((1 - p1) / (1 - p0))
    a, b = math.log((1 - beta) / alpha), math.log(beta / (1 - alpha))
    if p1 < p0:           # test for a regression: flip sign convention
        llr = -llr
        a, b = a, b
    dec = "accept H1" if llr >= a else "accept H0" if llr <= b else "continue"
    return llr, b, a, dec


# --------------------------------------------------------------------------- Bradley-Terry
def bradley_terry(wins: Dict[Tuple[str, str], float], pseudo: float = 0.5,
                  iters: int = 2000, tol: float = 1e-10) -> Dict[str, float]:
    """MM algorithm (Hunter 2004). wins[(i, j)] = number of times i beat j.
    `pseudo` adds that many wins to BOTH directions of every observed pair to keep the MLE finite.
    Returns Elo-scaled ratings (400*log10(strength)), centred at 0."""
    players = sorted({p for pair in wins for p in pair})
    w: Dict[Tuple[str, str], float] = {}
    for (i, j), v in wins.items():
        w[(i, j)] = w.get((i, j), 0.0) + v
    for (i, j) in list(w):
        w.setdefault((j, i), 0.0)
    for k in list(w):
        w[k] += pseudo
    s = {p: 1.0 for p in players}
    for _ in range(iters):
        new = {}
        for i in players:
            wi = sum(v for (a, _b), v in w.items() if a == i)
            den = 0.0
            for j in players:
                if j == i:
                    continue
                nij = w.get((i, j), 0.0) + w.get((j, i), 0.0)
                if nij:
                    den += nij / (s[i] + s[j])
            new[i] = wi / den if den else s[i]
        g = math.exp(sum(math.log(v) for v in new.values()) / len(new))
        new = {p: v / g for p, v in new.items()}
        if max(abs(new[p] - s[p]) for p in players) < tol:
            s = new
            break
        s = new
    return {p: 400 * math.log10(v) for p, v in s.items()}


# --------------------------------------------------------------------------- stratified comparison
def mantel_haenszel(strata: Sequence[Tuple[int, int, int, int]]) -> Dict[str, float]:
    """Stratified comparison of agent X vs agent Y across strata (e.g. opponent archetype x seat).
    Each stratum = (a, b, c, d): X wins, X losses, Y wins, Y losses.
    Returns MH common odds ratio (X vs Y), Robins-Breslow-Greenland 95% CI, CMH chi-square and p."""
    R = S = 0.0
    sPR = sPSQR = sQS = 0.0
    sa = sE = sV = 0.0
    for a, b, c, d in strata:
        n = a + b + c + d
        if n < 2:
            continue
        Rk, Sk = a * d / n, b * c / n
        P, Q = (a + d) / n, (b + c) / n
        R += Rk
        S += Sk
        sPR += P * Rk
        sPSQR += P * Sk + Q * Rk
        sQS += Q * Sk
        sa += a
        sE += (a + b) * (a + c) / n
        sV += (a + b) * (c + d) * (a + c) * (b + d) / (n * n * (n - 1))
    if R == 0 or S == 0:
        return {"or": float("nan"), "lo": float("nan"), "hi": float("nan"), "chi2": float("nan"), "p": float("nan")}
    or_mh = R / S
    var = sPR / (2 * R * R) + sPSQR / (2 * R * S) + sQS / (2 * S * S)
    se = math.sqrt(var)
    lo, hi = math.exp(math.log(or_mh) - Z95 * se), math.exp(math.log(or_mh) + Z95 * se)
    chi2 = (abs(sa - sE) - 0.5) ** 2 / sV if sV > 0 else float("nan")
    p = 2 * (1 - _N.cdf(math.sqrt(chi2))) if chi2 == chi2 else float("nan")
    return {"or": or_mh, "lo": lo, "hi": hi, "chi2": chi2, "p": p}


def weighted_rate(per_arch: Dict[str, Tuple[int, int]], weights: Dict[str, float],
                  n_boot: int = 4000, seed: int = 0) -> Tuple[float, float, float]:
    """Field-weighted win rate with a parametric-bootstrap 95% CI.
    per_arch[a] = (wins, games); weights[a] = share of field (renormalised over archetypes present)."""
    keys = [a for a in per_arch if a in weights and per_arch[a][1] > 0]
    tw = sum(weights[a] for a in keys)
    pt = sum(weights[a] / tw * per_arch[a][0] / per_arch[a][1] for a in keys)
    rnd = random.Random(seed)
    boots: List[float] = []
    for _ in range(n_boot):
        v = 0.0
        for a in keys:
            k, n = per_arch[a]
            v += weights[a] / tw * rnd.betavariate(k + 0.5, n - k + 0.5)
        boots.append(v)
    boots.sort()
    return pt, boots[int(0.025 * n_boot)], boots[int(0.975 * n_boot)]


# --------------------------------------------------------------------------- self-test and tables
def _selftest() -> None:
    def close(a: float, b: float, tol: float = 6e-4) -> bool:
        return abs(a - b) <= tol

    # Published Wilson intervals (4dalols/pokemon-agent PRs #3, #12, #14) -- implementation cross-check
    cases = [(47, 100, .375, .567), (32, 100, .237, .417), (45, 100, .356, .548),
             (216, 300, .667, .768), (193, 300, .588, .695), (117, 150, .707, .839), (80, 100, .711, .867)]
    for k, n, lo, hi in cases:
        a, b = wilson(k, n)
        assert close(a, lo, 1.2e-3) and close(b, hi, 1.2e-3), (k, n, a, b, lo, hi)
    d, z, p = two_prop_z(216, 300, 193, 300)
    assert abs(z - 2.0) < 0.05 and abs(p - 0.04) < 0.01, (z, p)
    assert n_two_sample(0.55, 0.50) == 1565 and n_one_sample(0.55) == 783
    assert abs(bo3_from_game(0.5) - 0.5) < 1e-12 and abs(game_from_bo3(bo3_from_game(0.6)) - 0.6) < 1e-9
    assert abs(binom_two_sided_p(60, 100) - 0.0569) < 1e-3
    # Bradley-Terry recovery on synthetic data
    rnd = random.Random(1)
    true = {"A": 200.0, "B": 0.0, "C": -100.0, "D": -100.0}
    wins: Dict[Tuple[str, str], float] = {}
    names = list(true)
    for _ in range(40000):
        i, j = rnd.sample(names, 2)
        pij = elo_p(true[i] - true[j])
        w, l = (i, j) if rnd.random() < pij else (j, i)
        wins[(w, l)] = wins.get((w, l), 0) + 1
    est = bradley_terry(wins, pseudo=0.0)
    off = sum(est.values()) / 4 - sum(true.values()) / 4
    for k in true:
        assert abs(est[k] - off - true[k]) < 12, (k, est[k], true[k])
    # Mantel-Haenszel: identical strata -> common OR recovered
    mh = mantel_haenszel([(60, 40, 50, 50)] * 6)
    assert abs(mh["or"] - (60 * 50) / (40 * 50)) < 1e-9
    print("selftest OK")


def _tables() -> None:
    print("== MDES (true win rate detectable at 80% power, alpha=.05 two-sided) ==")
    print(f"{'games':>6} {'vs fixed 50%':>14} {'two arms (each n)':>20}")
    for n in (100, 150, 300, 600, 1000, 1500, 3000):
        print(f"{n:>6} {mdes_one_sample(n):>14.3f} {mdes_two_sample(n):>20.3f}")
    print("\n== games needed for a target true win rate ==")
    for p1 in (0.53, 0.55, 0.575, 0.60, 0.65):
        print(f"p1={p1:.3f}: vs fixed 50% n={n_one_sample(p1):>5}; two independent arms n/arm={n_two_sample(p1, 0.5):>5}")
    print("\n== Wilson 95% half-width at p=0.5 ==")
    for n in (35, 100, 150, 300, 1000, 3000):
        lo, hi = wilson(n // 2, n)
        print(f"n={n:>5}: +/-{(hi - lo) / 2 * 100:4.1f} pp")
    print("\n== BO3 amplification of a single-game win rate ==")
    for p in (0.50, 0.52, 0.55, 0.60, 0.65, 0.70):
        print(f"game {p:.2f} -> BO3 {bo3_from_game(p):.3f}")
    print("\n== P(win) for a rating gap under two assumed scales (true scale unknown) ==")
    print(f"{'gap':>8} {'Elo-400':>9} {'probit b=100':>13}")
    for g in (25, 50, 100, 186.5, 386.5, 586.5, 686.5, 1186.5):
        print(f"{g:>8} {elo_p(g):>9.3f} {probit_p(g):>13.3f}")
    print("\n== SE of a ladder rating estimate after n episodes (opponents ~ equal rating) ==")
    print(f"{'n':>6} {'Elo-400':>9} {'probit100':>10}  (single submission; SE of a difference = x sqrt2)")
    for n in (35, 100, 300, 1000):
        print(f"{n:>6} {rating_se(n):>9.1f} {rating_se(n, 'probit100'):>10.1f}")
    print("\n== episodes EACH submission needs for a rating gap to be 95%-significant ==")
    print(f"{'gap':>6} {'Elo-400':>9} {'probit100':>10}")
    for g in (12.5, 25, 50, 100, 200):
        print(f"{g:>6} {episodes_to_resolve(g):>9} {episodes_to_resolve(g, 'probit100'):>10}")
    print("\n== SPRT: H0 p=0.50 vs H1 p=0.55 (alpha=beta=0.05) boundaries on games n (llr thresholds) ==")
    llr_hi = math.log(0.95 / 0.05)
    print(f"accept H1 when LLR >= {llr_hi:.3f}; accept H0 when LLR <= {-llr_hi:.3f}")
    print("\n== False-positive inflation from peeking (A/A, true p=0.5 vs 0.5, two arms, z-test at alpha=.05) ==")
    rnd = random.Random(7)
    sims, nmax, step = 4000, 1000, 50
    fp_final = fp_peek = 0
    for _ in range(sims):
        a = b = 0
        hit = False
        for n in range(step, nmax + 1, step):
            a += sum(rnd.random() < 0.5 for _ in range(step))
            b += sum(rnd.random() < 0.5 for _ in range(step))
            _, z, p = two_prop_z(a, n, b, n)
            if p < 0.05:
                hit = True
            if n == nmax and p < 0.05:
                fp_final += 1
        fp_peek += hit
    print(f"one look at n={nmax}: {fp_final / sims:.3f};  look every {step} games: {fp_peek / sims:.3f}")
    print("\n== distance to targets from 813.5 ==")
    for t in (1000, 1200, 1398.2, 1500, 2000):
        g = t - 813.5
        print(f"target {t:>7}: +{g:6.1f}  -> would beat today's 813.5 with P = {elo_p(g):.3f} (Elo-400) / {probit_p(g):.3f} (probit100)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--tables", action="store_true")
    a = ap.parse_args()
    if a.selftest or not (a.selftest or a.tables):
        _selftest()
    if a.tables:
        _tables()
