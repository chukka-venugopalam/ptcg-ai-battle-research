#!/usr/bin/env python3
"""bo3_ab_harness.py -- seat-swapped, process-isolated BO3 evaluation TEMPLATE for the cabt environment.

STATUS (read this first)
  * The scheduling / seat-swap / logging / Wilson-summary plumbing was exercised with a FAKE environment
    (PTCG_HARNESS_FAKE=1).  
  * The part that talks to `kaggle_environments` / the cabt engine was NOT executed: no SDK, no R2 card pool
    and no engine library were available where this was written.  Lines marked `VERIFY?` rest on facts quoted
    from public PRs (4dalols/pokemon-agent #3, #12, #14): `make("cabt", configuration={"bo": 3})`, agents passed
    as extracted `main.py` paths, final rewards like [1, -1], `remainingOverageTime` out of 600 s per agent.
  * Needs kaggle-environments MASTER (BO3 + R2 card pool); PyPI 1.32.7 is reported as single-game / 1267 cards.

Design rules it enforces
  * every match runs in its own spawned process that is killed on a wall-clock deadline (hung games happen);
  * candidate sits in seat 0 on even match indices and seat 1 on odd ones (seat balance by construction);
  * one JSON line per match: opponent label, seat, rewards, statuses, overage left, wall time, error text;
  * anything with a non-DONE status or an exception is counted as a RUNTIME FAILURE, never silently as a loss.

Known gaps (extend after inspecting env.steps on your SDK build)
  * game-level results inside a BO3, first/second-player per game, and per-decision latency are NOT recorded;
    only the match outcome, seat, statuses, remaining overage time and wall time are.
  * native RNG is reported as unseedable (4dalols PR #3), so `seed` only labels a match / seeds the fake env.
  * two agents cannot both live in /kaggle_simulations/agent; each agent must find its own files robustly.

Usage
  python bo3_ab_harness.py --cand ./cand_dir --opp hydrapple=./pilots/hydrapple:0.143 \
         --opp abomasnow=./pilots/abomasnow:0.141 --matches 100 --workers 6 --out run1.jsonl
  PTCG_HARNESS_FAKE=1 python bo3_ab_harness.py --cand a --opp x=b:1 --matches 40 --workers 2 --out /tmp/fake.jsonl
Each --cand/--opp directory must contain the agent's main.py exactly as packaged for Kaggle.
"""
from __future__ import annotations

import argparse
import json
import zlib
import multiprocessing as mp
import os
import random
import sys
import time
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ptcg_eval_stats import weighted_rate, wilson  # noqa: E402

FAKE = os.environ.get("PTCG_HARNESS_FAKE") == "1"


def _play(job: dict, q: "mp.Queue") -> None:
    """Child process: run ONE match and put a result dict on the queue."""
    t0 = time.time()
    out = {k: job[k] for k in ("label", "idx", "cand_seat", "seed")}
    try:
        if FAKE:
            rnd = random.Random(job["seed"])
            cand_wins = rnd.random() < job.get("fake_p", 0.5)
            r_c = 1 if cand_wins else -1
            rewards = [r_c, -r_c] if job["cand_seat"] == 0 else [-r_c, r_c]
            out.update(statuses=["DONE", "DONE"], rewards=rewards, overage_left=[500.0, 500.0])
        else:
            from kaggle_environments import make  # VERIFY? needs kaggle-environments master
            paths = [job["cand_main"], job["opp_main"]]
            if job["cand_seat"] == 1:
                paths.reverse()
            os.chdir(os.path.dirname(job["cand_main"]))  # agents must resolve their own files robustly
            env = make("cabt", configuration={"bo": 3})   # VERIFY? config key per 4dalols PR #12
            env.run(paths)                                 # VERIFY? file-path agents, as in PR #3/#12
            fin = env.steps[-1]
            out["statuses"] = [s["status"] if isinstance(s, dict) else s.status for s in fin]
            out["rewards"] = [s["reward"] if isinstance(s, dict) else s.reward for s in fin]
            ov = []
            for s in fin:
                obs = s["observation"] if isinstance(s, dict) else s.observation
                ov.append(obs.get("remainingOverageTime") if hasattr(obs, "get") else None)  # VERIFY? field name
            out["overage_left"] = ov
            out["n_steps"] = len(env.steps)
    except Exception as e:  # noqa: BLE001 -- a crash is data
        out["error"] = f"{type(e).__name__}: {e}"[:500]
    out["wall_s"] = round(time.time() - t0, 2)
    q.put(out)


def _jobs(cand: str, opps: Dict[str, Tuple[str, float]], matches: int, seed0: int, fake_p: float) -> List[dict]:
    jobs = []
    for label, (path, _w) in opps.items():
        for i in range(matches):
            jobs.append(dict(label=label, idx=i, cand_seat=i % 2, seed=seed0 + zlib.crc32(f'{label}:{i}'.encode()) % 10**9,
                             cand_main=os.path.join(cand, "main.py"), opp_main=os.path.join(path, "main.py"),
                             fake_p=fake_p))
    random.Random(seed0).shuffle(jobs)  # interleave opponents so a crash late in the run does not bias one matchup
    return jobs


def run(jobs: List[dict], workers: int, deadline_s: float, out_path: str) -> List[dict]:
    ctx = mp.get_context("spawn")
    pending, running, results = list(jobs), [], []
    with open(out_path, "a") as fh:
        while pending or running:
            while pending and len(running) < workers:
                j = pending.pop()
                q = ctx.Queue()
                p = ctx.Process(target=_play, args=(j, q))
                p.start()
                running.append((p, q, j, time.time()))
            time.sleep(0.05)
            for item in list(running):
                p, q, j, t0 = item
                res: Optional[dict] = None
                if not q.empty():
                    res = q.get()
                elif not p.is_alive():
                    res = dict(label=j["label"], idx=j["idx"], cand_seat=j["cand_seat"], seed=j["seed"],
                               error=f"child exited rc={p.exitcode} without result")
                elif time.time() - t0 > deadline_s:
                    p.terminate()
                    res = dict(label=j["label"], idx=j["idx"], cand_seat=j["cand_seat"], seed=j["seed"],
                               error=f"wall-clock deadline {deadline_s}s exceeded (killed)")
                if res is not None:
                    p.join(timeout=5)
                    running.remove(item)
                    results.append(res)
                    fh.write(json.dumps(res) + "\n")
                    fh.flush()
    return results


def summarise(results: List[dict], weights: Dict[str, float]) -> None:
    per: Dict[str, List[int]] = defaultdict(lambda: [0, 0])
    seat: Dict[Tuple[str, int], List[int]] = defaultdict(lambda: [0, 0])
    fails = defaultdict(int)
    for r in results:
        bad = ("error" in r) or any(s != "DONE" for s in r.get("statuses", ["?"]))
        if bad:
            fails[r["label"]] += 1
            continue
        c = r["cand_seat"]
        win = r["rewards"][c] > r["rewards"][1 - c]
        per[r["label"]][0] += int(win)
        per[r["label"]][1] += 1
        seat[(r["label"], c)][0] += int(win)
        seat[(r["label"], c)][1] += 1
    print(f"{'opponent':<22}{'W-N':>10}{'rate':>8}{'Wilson95':>18}{'seat0':>8}{'seat1':>8}{'FAIL':>6}")
    for lab, (k, n) in sorted(per.items()):
        lo, hi = wilson(k, n)
        s0 = seat[(lab, 0)]
        s1 = seat[(lab, 1)]
        f = lambda x: f"{x[0] / x[1]:.2f}" if x[1] else "n/a"  # noqa: E731
        print(f"{lab:<22}{f'{k}-{n}':>10}{k / n:>8.3f}{f'[{lo:.3f},{hi:.3f}]':>18}{f(s0):>8}{f(s1):>8}{fails[lab]:>6}")
    if per:
        pt, lo, hi = weighted_rate({a: (v[0], v[1]) for a, v in per.items()}, weights)
        print(f"field-weighted win rate: {pt:.3f}  (bootstrap 95% [{lo:.3f}, {hi:.3f}])")
    tot_fail = sum(fails.values())
    print(f"runtime failures (errors / non-DONE / killed): {tot_fail}  <- acceptance requires 0")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cand", required=True)
    ap.add_argument("--opp", action="append", required=True, help="label=dir[:weight]")
    ap.add_argument("--matches", type=int, default=100, help="BO3 matches per opponent (half per seat)")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--deadline", type=float, default=1500.0, help="wall-clock seconds per BO3 before kill")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--fake-p", type=float, default=0.5)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    opps: Dict[str, Tuple[str, float]] = {}
    for spec in a.opp:
        lab, rest = spec.split("=", 1)
        path, _, w = rest.partition(":")
        opps[lab] = (path, float(w) if w else 1.0)
    jobs = _jobs(a.cand, opps, a.matches, a.seed, a.fake_p)
    res = run(jobs, a.workers, a.deadline, a.out)
    summarise(res, {k: v[1] for k, v in opps.items()})


if __name__ == "__main__":
    main()
