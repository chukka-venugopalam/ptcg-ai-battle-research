#!/usr/bin/env python3
"""build_meta_census.py -- rebuild a current-meta census from OFFICIAL Playground episode replays.

STATUS: NOT RUN on official data (no Kaggle access in the Mission-3 sandbox).  Plumbing is validated on replays generated
locally by the real cabt engine (tests/test_census.py).  The schema of the official Episodes dataset is UNVERIFIED: the parser
expects an env.toJSON()-style object {"steps": [[{"action":..,"reward":..,"status":..}, {...}], ...], "rewards": [r0, r1]}
and FAILS LOUDLY (non-zero exit with --strict, per-episode `schema_error` rows otherwise) instead of guessing.

    python build_meta_census.py --episodes DIR_OR_ZIP [--manifest manifest.csv] [--out CURRENT_META_REBUILT.csv] [--strict]

Card names / archetype labels use the engine's own card table (installed SDK).  Archetype labels are a HEURISTIC (top-2 Pokemon
names by copies x weight); the exact-list hash is the primary key.  Never treat this as pilot-adjusted deck strength.
"""
from __future__ import annotations

import argparse
import collections
import csv
import glob
import hashlib
import json
import os
import sys
import zipfile
from typing import Dict, Iterator, List, Optional, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def iter_replays(src: str) -> Iterator[Tuple[str, dict]]:
    if os.path.isdir(src):
        for fp in sorted(glob.glob(os.path.join(src, "**", "*.json"), recursive=True)):
            with open(fp) as fh:
                yield os.path.basename(fp), json.load(fh)
    elif zipfile.is_zipfile(src):
        with zipfile.ZipFile(src) as z:
            for n in sorted(z.namelist()):
                if n.endswith(".json") and not n.endswith("manifest.json"):
                    yield os.path.basename(n), json.loads(z.read(n))
    else:
        raise SystemExit(f"--episodes must be a directory or a zip: {src}")


def decks_and_rewards(rep: dict) -> Tuple[List[List[int]], List[Optional[float]]]:
    steps = rep.get("steps") or (rep.get("replay") or {}).get("steps")
    if not steps:
        raise ValueError("no 'steps' list")
    for st in steps[:6]:
        acts = [s.get("action") for s in st]
        if len(acts) == 2 and all(isinstance(a, list) and len(a) == 60 and all(type(x) is int for x in a) for a in acts):
            decks = acts
            break
    else:
        raise ValueError("no step with two 60-int deck actions among the first 6 steps")
    rewards = rep.get("rewards") or [s.get("reward") for s in steps[-1]]
    return decks, list(rewards)


def archetype_label(deck: List[int], by_id: Dict[int, dict]) -> str:
    score: collections.Counter = collections.Counter()
    for cid in deck:
        c = by_id.get(cid)
        if not c or c["cardType"] != 0:
            continue
        w = 3 if (c.get("megaEx") or c.get("ex")) else 2 if c.get("stage2") else 1
        score[c["name"]] += w
    return " / ".join(n for n, _ in score.most_common(2)) or "unknown"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--episodes", required=True)
    ap.add_argument("--manifest")
    ap.add_argument("--out", default="CURRENT_META_REBUILT.csv")
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--top", type=int, default=40)
    a = ap.parse_args()
    by_id: Dict[int, dict] = {}
    try:
        import bo3_ab_harness as H
        by_id = {c["cardId"]: c for c in H.r2_card_table()[0]}
    except Exception as e:  # noqa: BLE001
        print(f"WARNING: engine card table unavailable ({type(e).__name__}); archetype labels = 'NOT RUN'", file=sys.stderr)
    manifest: Dict[str, dict] = {}
    if a.manifest:
        with open(a.manifest, newline="") as fh:
            for row in csv.DictReader(fh):
                key = next((row[k] for k in ("episode_id", "EpisodeId", "id", "episode") if k in row), None)
                if key is not None:
                    manifest[str(key)] = row
        print(f"manifest rows: {len(manifest)} (columns auto-matched by name; VERIFY against the real manifest.csv)")
    exact: collections.Counter = collections.Counter()
    arche: collections.Counter = collections.Counter()
    wins: collections.Counter = collections.Counter()
    deck_of: Dict[str, List[int]] = {}
    n_ok = 0
    errors: List[Tuple[str, str]] = []
    for name, rep in iter_replays(a.episodes):
        try:
            decks, rewards = decks_and_rewards(rep)
        except Exception as e:  # noqa: BLE001
            errors.append((name, f"{type(e).__name__}: {e}"))
            continue
        n_ok += 1
        for seat in (0, 1):
            h = hashlib.sha1(",".join(map(str, sorted(decks[seat]))).encode()).hexdigest()[:12]
            exact[h] += 1
            deck_of[h] = decks[seat]
            arche[archetype_label(decks[seat], by_id) if by_id else "NOT RUN"] += 1
            if rewards and rewards[seat] is not None and rewards[seat] > 0:
                wins[h] += 1
    total = 2 * n_ok
    with open(a.out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["record_type", "name", "count_entries", "share_pct", "wins_in_sample", "n_episodes_parsed", "n_episodes_failed",
                    "evidence_tag", "notes"])
        w.writerow(["status", "census", total, "", "", n_ok, len(errors), "verified" if n_ok else "unknown",
                    "episodes parsed from local files; heuristic archetype labels; NOT pilot-adjusted"])
        for lab, c in arche.most_common(a.top):
            w.writerow(["archetype_heuristic", lab, c, round(100 * c / total, 2) if total else "", "", "", "", "verified", "heuristic-v0 label"])
        for h, c in exact.most_common(a.top):
            names = collections.Counter(by_id[i]["name"] for i in deck_of[h] if i in by_id)
            w.writerow(["exact_list", h, c, round(100 * c / total, 2) if total else "", wins[h], "", "", "verified",
                        "; ".join(f"{k}x{v}" for k, v in names.most_common(5))])
        for nme, err in errors:
            w.writerow(["schema_error", nme, "", "", "", "", "", "unknown", err])
    print(f"parsed {n_ok} episodes, {len(errors)} failed, {total} deck entries -> {a.out}")
    if errors:
        print(f"first failure: {errors[0]}", file=sys.stderr)
    return 1 if (a.strict and errors) else 0


if __name__ == "__main__":
    sys.exit(main())
