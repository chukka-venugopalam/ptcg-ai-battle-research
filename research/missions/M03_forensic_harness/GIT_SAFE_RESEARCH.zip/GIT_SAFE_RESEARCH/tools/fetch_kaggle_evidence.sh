#!/usr/bin/env bash
# fetch_kaggle_evidence.sh -- READ-ONLY evidence collection for Phase 1 / Phase 5.   STATUS: NOT RUN (no Kaggle credentials / egress
# to kaggle.com in the Mission-3 sandbox).  Run it on a machine where `kaggle` is authenticated.  It never uploads anything.
#
# usage:  COMP=<playground-competition-slug> bash fetch_kaggle_evidence.sh [outdir]
# The slug is on the competition URL (https://www.kaggle.com/competitions/<slug>).  The subcommands below are INFERRED from the
# Kaggle CLI's simulation-competition commands: confirm names with `kaggle competitions -h` before trusting any output.
set -u
COMP="${COMP:?set COMP to the Playground competition slug}"
OUT="${1:-kaggle_evidence_$(date -u +%Y%m%dT%H%M%SZ)}"
mkdir -p "$OUT"
log() { echo "### $(date -u +%FT%TZ)  $*" | tee -a "$OUT/COMMAND_LOG.txt"; }
run() { log "$*"; { "$@"; echo "[exit $?]"; } > "$OUT/$(echo "$*" | tr -c 'A-Za-z0-9._-' '_' | cut -c1-90).txt" 2>&1; }

run kaggle --version
# 1) THE active-slot question: filenames, ids, order, timestamps, scores, status.  Read this BEFORE any upload.
run kaggle competitions submissions -c "$COMP" -v
# 2) leaderboard snapshot (live rating scale, top agents)
run kaggle competitions leaderboard -c "$COMP" --show
# 3) episodes per submission (needs submission ids from step 1; edit IDS=...)
IDS="${IDS:-}"
for sid in $IDS; do
  run kaggle competitions episodes "$sid" -v
done
# 4) >= 50 replays + logs per ACTIVE agent (edit EPISODE_IDS=... from the episodes listing)
for eid in ${EPISODE_IDS:-}; do
  mkdir -p "$OUT/replays"
  run kaggle competitions replay "$eid" -p "$OUT/replays"
  run kaggle competitions logs "$eid" 0 -p "$OUT/replays"
  run kaggle competitions logs "$eid" 1 -p "$OUT/replays"
done
# 5) official episode datasets + manifest.csv for the meta census (dataset slug from the competition's Data tab; do not redistribute)
echo "Download the latest official Episodes dataset(s) from the Data tab, then:  python build_meta_census.py --episodes <dir|zip> --manifest manifest.csv"
# 6) rules / deadline / active-submission semantics: save the page text with an access date
echo "Open https://www.kaggle.com/competitions/$COMP/rules and record: deadline, 'latest N submissions' wording, data/code-sharing restrictions." | tee -a "$OUT/COMMAND_LOG.txt"
sha256sum "$OUT"/*.txt > "$OUT/SHA256SUMS" 2>/dev/null || true
